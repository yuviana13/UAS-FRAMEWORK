from django.shortcuts import render, redirect
from dashboard.forms import form_barang, form_makanan, form_minuman
from django.contrib import messages
from dashboard.models import Barang, makan, minuman
# Create your views here.


def home(request):
    nama = 'Home'
    konteks = {
        'title': nama,
    }
    return render(request, 'index.html', konteks)


# tambah barang
def tambah_barang(request):
    if request.POST:
        form = form_barang(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Data Berhasil disimpan')
            form = form_barang()
            konteks = {
                'form': form,
            }
            return render(request, 'tambah_brg.html', konteks)
    else:
        form = form_barang
        konteks = {
            'form': form,
        }
    return render(request, 'tambah_brg.html', konteks)

def update_brg(request, id_barang):
    barangs = Barang.objects.get(id=id_barang)
    if request.POST:
        form = form_barang(request.POST, instance=barangs)
        if form.is_valid():
            form.save()
            messages.success(request, 'Data Berhasil diubah')
            return redirect('update_brg', id_barang=id_barang)
    else:
        form = form_barang(instance=barangs)
        konteks = {
            'form': form,
            'barangs': barangs,
        }
    return render(request, 'ubah_brg.html', konteks)

def delete_brg(request, id_barang):
    barangs = Barang.objects.filter(id=id_barang)
    barangs.delete()
    messages.success(request, 'Data berhasil dihapus')
    return redirect('Barang')

def Barang_view(request):
    barangs = Barang.objects.all()
    konteks = {
        'barangs': barangs
    }
    return render(request, 'tampil_brg.html', konteks)



# tabel makanan
def tambah_makanan(request):
    if request.POST:
        form = form_makanan(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Data Berhasil disimpan')
            form = form_makanan()
            konteks = {
                'form': form,
            }
            return render(request, 'tambah_makan.html', konteks)
    else:
        form = form_makanan
        konteks = {
            'form': form,
        }
    return render(request, 'tambah_makan.html', konteks)

def update_makan(request, id_makan):
    makans = makan.objects.get(id=id_makan)
    if request.POST:
        form = form_makanan(request.POST, instance=makans)
        if form.is_valid():
            form.save()
            messages.success(request, 'Data Berhasil diubah')
            return redirect('ubah_makan', id_makan=id_makan)
    else:
        form = form_makanan(instance=makans)
        konteks = {
            'form': form,
            'makans': makans,
        }
    return render(request, 'ubah_makan.html', konteks)

def delete_makan(request, id_makan):
    makans = makan.objects.filter(id=id_makan)
    makans.delete()
    messages.success(request, 'Data berhasil dihapus')
    return redirect('makan')

def Makan_view(request):
    makans = makan.objects.all()
    konteks = {
        'makans': makans,
    }
    return render(request, 'tampil_makan.html', konteks)


# Tabel Minuman
def tambah_minuman(request):
    if request.POST:
        form = form_minuman(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Data Berhasil disimpan')
            form = form_minuman()
            konteks = {
                'form': form,
            }
            return render(request, 'tambah_minum.html', konteks)
    else:
        form = form_minuman
        konteks = {
            'form': form,
        }
    return render(request, 'tambah_minum.html', konteks)

def update_minum(request, id_minum):
    minumans = minuman.objects.get(id=id_minum)
    if request.POST:
        form = form_minuman(request.POST, instance=minumans)
        if form.is_valid():
            form.save()
            messages.success(request, 'Data Berhasil diubah')
            return redirect('ubah_minum', id_minum=id_minum)
    else:
        form = form_makanan(instance=minumans)
        konteks = {
            'form': form,
            'minumans': minumans,
        }
    return render(request, 'ubah_minum.html', konteks)

def delete_minum(request, id_minuman):
    minumans = minuman.objects.filter(id=id_minuman)
    minumans.delete()
    messages.success(request, 'Data berhasil dihapus')
    return redirect('minuman')

def minuman_view(request):
    minumans = minuman.objects.all()
    konteks = {
        'minumans': minumans,
    }
    return render(request, 'tampil_minum.html', konteks)

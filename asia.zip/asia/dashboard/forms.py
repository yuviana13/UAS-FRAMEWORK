from django import forms
from django.forms import ModelForm
from dashboard.models import Barang, makan, minuman


class form_barang(ModelForm):
    class Meta:
        model = Barang
        fields = '__all__'

        widgets = {
            'kode': forms.TextInput({'class':'form-control'}),
            'nama': forms.TextInput({'class':'form-control'}),
            'stok': forms.TextInput({'class':'form-control'}),
            'harga': forms.TextInput({'class':'form-control'}),
            'link_gbr': forms.TextInput({'class':'form-control'}),
            'jenis': forms.Select({'class':'form-control'}),
        }

class form_makanan(ModelForm):
    class Meta:
        model = makan
        fields = '__all__'

        widgets = {
            'nama': forms.TextInput({'class':'form-control'}),
            'harga': forms.TextInput({'class':'form-control'}),
            'jumlah': forms.TextInput({'class':'form-control'}),
            'link_gbr': forms.TextInput({'class':'form-control'}),
        }

class form_minuman(ModelForm):
    class Meta:
        model = minuman
        fields = '__all__'

        widgets = {
            'nama': forms.TextInput({'class':'form-control'}),
            'harga': forms.TextInput({'class':'form-control'}),
            'jumlah': forms.TextInput({'class':'form-control'}),
            'link_gbr': forms.TextInput({'class':'form-control'}),
        }
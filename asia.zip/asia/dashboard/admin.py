from django.contrib import admin
from dashboard.models import Jenis, Barang, makan, minuman
# Register your models here.


class kolomBarang(admin.ModelAdmin):
    list_display = ['kode', 'nama', 'stok', 'harga', 'link_gbr']
    search_fields = ['kode', 'nama']
    list_filter = ('jenis_id',)
    list_per_page = 3

class kolomMakan(admin.ModelAdmin):
    list_display = ['nama', 'harga', 'jumlah', 'link_gbr']
    search_fields = ['nama']
    list_filter = ('nama',)
    list_per_page = 3

class kolomMinuman(admin.ModelAdmin):
    list_display = ['nama', 'harga', 'jumlah', 'link_gbr']
    search_fields = ['nama']
    list_filter = ('nama',)
    list_per_page = 3

admin.site.register(Jenis)
admin.site.register(Barang, kolomBarang)
admin.site.register(makan, kolomMakan)
admin.site.register(minuman, kolomMinuman)
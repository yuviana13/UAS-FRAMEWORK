"""asia URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.shortcuts import render
from dashboard.views import *

def home(request):
    nama = "Home"
    konteks = {
        'title': nama,
    }
    return render(request, 'index.html', konteks)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name='home'),
    path('Vbrg/', Barang_view, name='Barang'),
    path('ubahBrg/<int:id_barang>', update_brg, name='update_brg'),
    path('hapus/<int:id_barang>', delete_brg, name='hapus_brg'),
    path('addBrg/', tambah_barang, name='add_brg'),
    path('Vmakan/', Makan_view, name='makan'),
    path('addMakan/', tambah_makanan, name='add_makan'),
    path('ubahMakan/<int:id_makan>', update_makan, name='ubah_makan'),
    path('hapusMakan/<int:id_makan>', delete_makan, name='hapus_makan'),
    path('Vminum/', minuman_view, name='minum'),
    path('addMinum/', tambah_minuman, name='add_minum'),
    path('ubahMinum/<int:id_minum>', update_minum, name='ubah_minum'),
    path('hapusMinum/<int:id_minum>', delete_minum, name='hapus_minum'),

]
